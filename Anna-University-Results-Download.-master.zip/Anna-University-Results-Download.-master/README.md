# Anna-University-Results-Download.
Download  complete Anna University Results for all departments #Only for current semester
