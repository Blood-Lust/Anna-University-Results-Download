
# coding: utf-8

# In[10]:

import csv
import requests

from bs4 import BeautifulSoup
import pandas as pd


# In[11]:

url = 'http://aucoe.annauniv.edu/cgi-bin/result/cgrade.pl'


# In[ ]:
import sys

'''
header = map(lambda x : x.contents[0],header)
header.append('Name')
header.append('University')
header.append('Branch')
soup = BeautifulSoup(r.text)
spamwriter = []
r = requests.post(url, data={'regno' : 910713205020})

table = soup.find_all('table')

header = table[2].findAll('tr')[0:][0].find_all('font')


header.append(\n)
spamwriter.writerow(header)
'''
spamwriter = []
df=pd.read_csv(sys.argv[1])
li=0
for iop,r1 in df.iterrows():
    print 'At row ' + str(li)
    li=li+1
    for i in range(int(r1['start']),int(r1['end'])):
        studata = dict()
        regno= {'regno': i}
        r = requests.post(url, data=regno)
        soup = BeautifulSoup(r.text)
        table = soup.find_all('table')
        rows = table[2].findAll('tr')[0:]
        '''
        header = map(lambda x : x.contents[0],header)
        header.append('Name')
        header.append('University')
        header.append('Branch')
        header = table[2].findAll('tr')[0:][0].find_all('font')
       
       
        studata['header'] = header
        '''
        headname = table[1].find_all('strong')
        try:
            headname = map(lambda x : x.contents[0],headname)
        except:
            continue
        subs=[]
        res=[]
        subs = dict()
        for row in rows[1:]:
            data = row.findAll('td')
            try:
                subs[data[0].find('strong').contents[0]] = data[1].find('strong').contents[0]
                
            except:
                continue
        spamwriter.append(studata)
        studata['res'] = subs
        studata['studentdetail'] = headname
        


# In[9]:

spamwriter


# In[6]:

import json
with open(sys.argv[2], 'w') as outfile:
    json.dump(spamwriter, outfile)


# In[7]:

import pandas as pd
import numpy as np


# In[8]:

df = pd.read_json(sys.argv[2])


# In[9]:

studata


# In[ ]:




# In[ ]:




# In[ ]:



