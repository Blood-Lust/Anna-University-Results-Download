
# coding: utf-8

# In[13]:

depts=[101,102,103,104,105,106,107,112,113,114,120,121,184,185,203,205,212,214,216,219,220]


# In[14]:

import pandas as pd


# In[15]:
import sys
df=pd.read_csv(sys.argv[1])


# In[16]:

df1=pd.DataFrame()


# In[17]:

df = df[:-1]


# In[ ]:




# In[18]:

listofcols = list()
listofcols2 = list()
for index, row in df.iterrows():
    for element in depts:
        listofcols.append(str(row['Examination code'])+str(13)+str(element)+'001')
        listofcols2.append(str(row['Examination code'])+str(13)+str(element)+str(120))
    #print row['callcode']


# In[19]:

len(listofcols)*120


# In[20]:

df1['start']=listofcols
df1['end']=listofcols2


# In[21]:

df1.to_csv(sys.argv[2])


# In[22]:

df1


# In[ ]:




# In[ ]:



